# getpasswd in Go

No longer maintained. You should just use [terminal](https://golang.org/x/crypto/ssh/terminal).
